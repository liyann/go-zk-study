package main

import (
	"net/http"

	"github.com/labstack/echo"
)

func main() {

	servers := []string{"localhost:32772", "localhost:32773", "localhost:32774"}
	client, err := NewClient(servers, "/websocket", 10)
	if err != nil {
		panic(err)
	}
	defer client.Close()
	node1 := &ServiceNode{"manager", "127.0.0.1", 4000, 1}
	// node2 := &ServiceNode{"user", "127.0.0.1", 4001, 2}
	// node3 := &ServiceNode{"user", "127.0.0.1", 4002, 3}
	// node1Path := ""
	if _, err = client.Register(node1); err != nil {
		panic(err)
	}

	e := echo.New()
	e.GET("/", func(c echo.Context) error {
		return c.String(http.StatusOK, "Hello, World!")
	})

	e.GET("/ws", func(c echo.Context) error {
		nodes, err := client.GetNodes("connect")
		if err != nil {
			panic(err)
		}
		url := client.getMinimumConnURL(nodes)
		return c.String(http.StatusOK, url)
	})

	e.POST("/sendMessage", func(c echo.Context) error {
		return c.String(http.StatusOK, "发送成功")
	})
	e.Logger.Fatal(e.Start(":1323"))
}
